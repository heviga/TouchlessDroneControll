# Human-Detection-and-Tracking-through-the-DJI-Tello-minidrone

A simple Python script used to programme the DJI Tello minidrone to make it able to detect and track people.

The mobileNet-SSD has been used for the detection task.

A demonstration video can be found here: https://youtu.be/JBI2nYOy-GQ

[![IMAGE ALT TEXT HERE](https://img.youtube.com/vi/JBI2nYOy-GQ/0.jpg)](https://youtu.be/JBI2nYOy-GQ)

import pickle


with open('gesture_data.pkl', 'rb') as f:
    data = pickle.load(f)

print(data)
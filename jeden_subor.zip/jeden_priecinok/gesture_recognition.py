import cv2 as cv2
import mediapipe as mp
import numpy as np
import pickle
from threading import Thread, Event
import time

mp_hands = mp.solutions.hands

hands = mp_hands.Hands(max_num_hands=1)
# Load the trained model
with open("gesture_model.pkl", "rb") as f:
    model_data = pickle.load(f)
    clf = model_data['classifier']
    scaler = model_data['scaler']

prediction = None
stop_event = Event()
#stream

def call_repeatedly(interval, func, *args):
    def loop():
        while not stop_event.is_set():
            func(*args)  # Pass the scaler and classifier to the function
            stop_event.wait(interval)
    Thread(target=loop).start()
def hand_landmarks(scaler, clf, frame):
    global prediction
    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)  # Convert to RGB
    results = hands.process(frame_rgb)

    if results.multi_hand_landmarks:
        landmarks = np.array([[lmk.x, lmk.y, lmk.z] for lmk in results.multi_hand_landmarks[0].landmark]).flatten()
        landmarks = scaler.transform([landmarks])  # Normalize the landmarks
        prediction = clf.predict(landmarks)[0]  # Make a prediction
        print(f"Prediction: {prediction}")  # Debugging line to print prediction
    else:
        print("No hand landmarks detected.")







#
# MOVE TELLO

def control(tello, prediction, frame):

    # global prediction
    if prediction:
        if prediction == 'fist':
            tello.forward(30)
            time.sleep(1)
            tello.forward(0)
        elif prediction == 'ok':
            tello.backward(30)
            tello.sleep(1)
            tello.backward(0)
        elif prediction == 'palm':
            tello.sleep(5)
            tello.backward(0)
        elif prediction == 'like':
            tello.clockwise(30)
            tello.sleep(1)
            tello.clockwise(0)
        elif prediction == 'rock':
            tello.flip_back
        elif prediction == 'up':
            tello.up(30)
            tello.sleep(1)
            tello.up(0)
        elif prediction == 'down':
            tello.down(30)
        elif prediction == 'peace':
            cv2.imwrite("picture.png", frame)






#take_picture


# # PRINT PREDICTION
#
# def control(tello):
#
#     global  prediction #frame_read
#     if prediction:
#         if prediction == 'like':  # otockalajk
#             cv2.imwrite("otocka")
#         elif prediction == 'up':  # UP
#             cv2.imwrite("hore")
#         elif prediction == 'palm':  # stop
#             cv2.imwrite("stop")
#         elif prediction == 'fist':  # forward
#             cv2.imwrite("dopredu")
#         elif prediction == 'rock':  # backwards
#             cv2.imwrite("dozadu")
#         elif prediction == 'down':  # down
#             cv2.imwrite("dole")
#         elif prediction == 'ok':  # ok flip
#             cv2.imwrite("flip")
#         elif prediction == 'peace': # peace  fotka
#             cv2.imwrite("peace")







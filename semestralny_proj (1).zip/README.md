# iam-thesis-template
B5 LaTeX template primarily intended for students at FCFT, STU in Bratislava

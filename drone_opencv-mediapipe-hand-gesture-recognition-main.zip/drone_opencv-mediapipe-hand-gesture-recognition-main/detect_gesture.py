import cv2
import mediapipe as mp
from model import KeyPointClassifier
import landmark_utils as u
import sys
import traceback
import tellopy
import tensorflow as tf
from tensorflow import keras
import pickle
from threading import Thread, Event
import time
import numpy as np
import av
stop_event = Event()

def call_repeatedly(interval, func, *args):
    def loop():
        while not stop_event.is_set():
            func(*args)  # Pass the scaler and classifier to the function
            stop_event.wait(interval)
    Thread(target=loop).start()


def control(tello, image, prediction):
    tello.palm_land()

    if prediction:
        if prediction in ['fist', 'call me', 'stop', 'rock', 'live long', 'thumbs up', 'thumbs down', 'peace']:
            if prediction == 'fist':
                tello.forward(30)
                time.sleep(1)
                tello.forward(0)
            elif prediction == 'call me':
                tello.backward(30)
                time.sleep(1)
                tello.backward(0)
            elif prediction == 'stop':
                time.sleep(5)
                tello.backward(0)
            elif prediction == 'rock':
                tello.flip_forward()
            elif prediction == 'live long':
                tello.flip_back()
            elif prediction == 'thumbs up':
                tello.up(30)
                time.sleep(1)
                tello.up(0)
            elif prediction == 'thumbs down':
                tello.down(30)
                time.sleep(1)
                tello.down(0)
            elif prediction == 'peace':
                cv2.imwrite("picture.png", image)
        else:
            tello.hover()
    else:
        prediction = 'No Hand Detected'
        tello.hover()

    return prediction


def main():
    mp_hands = mp.solutions.hands
    # hands = mp_hands.Hands(max_num_hands=1, min_detection_confidence=0.7)
    mpDraw = mp.solutions.drawing_utils
    mp_drawing_styles = mp.solutions.drawing_styles

    kpclf = KeyPointClassifier()

    gestures = {
        # 1 -like
        # 2 - up
        # 3 - palm
        # 4 - fist
        # 5 - rock
        # 6 - down
        # 7 - ok
        # 8 - peace
        0: "Like",
        1: "Up",
        2: "Palm",
        3: "Fist",
        4: "Rock"
    }

    with mp_hands.Hands(
            model_complexity=0,
            min_detection_confidence=0.5,
            min_tracking_confidence=0.5) as hands:

        tello = tellopy.Tello()
        gesture_recognition_started = False

        try:
            tello.connect()
            tello.wait_for_connection(60.0)

            retry = 3
            container = None
            while container is None and 0 < retry:
                retry -= 1
                try:
                    container = av.open(tello.get_video_stream())
                except av.AVError as ave:
                    print(ave)
                    print('retry...')

            #tello.takeoff()
            frame_skip = 300

            while True:
                for frame in container.decode(video=0):
                    if 0 < frame_skip:
                        frame_skip = frame_skip - 1
                        continue
                    key = cv2.waitKey(1)
                    image = cv2.cvtColor(np.array(frame.to_image()), cv2.COLOR_RGB2BGR)

                    image.flags.writeable = False #nemodifikujeme image

                    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB) #az tu
                    results = hands.process(image)

                    # Draw the hand annotations on the image.
                    image.flags.writeable = True
                    image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
                    gesture_index = 4
                    if results.multi_hand_landmarks:
                        for hand_landmarks in results.multi_hand_landmarks:
                            landmark_list = u.calc_landmark_list(image, hand_landmarks)
                            keypoints = u.pre_process_landmark(landmark_list)
                            gesture_index = kpclf(keypoints)

                            prediction = gestures[gesture_index]

                            mpDraw.draw_landmarks(
                                image,
                                hand_landmarks,
                                mp_hands.HAND_CONNECTIONS,
                                mp_drawing_styles.get_default_hand_landmarks_style(),
                                mp_drawing_styles.get_default_hand_connections_style())

                        if key == ord("s"):
                            control(tello, image, prediction)

                    if cv2.waitKey(2) == ord('q'):
                        break

                    cv2.putText(image, gestures[gesture_index],
                            (10, 30), cv2.FONT_HERSHEY_DUPLEX, 1, 255)
                    cv2.imshow('MediaPipe Hands', image)

                tello.land()

        except Exception as ex:
            exc_type, exc_value, exc_traceback = sys.exc_info()
            traceback.print_exception(exc_type, exc_value, exc_traceback)
            print(ex)

        finally:
            tello.land()
            tello.quit()
            cv2.destroyAllWindows()




if __name__ == '__main__':
    main()
import cv2
import mediapipe as mp
import numpy as np
import pickle
from threading import Thread, Event
from djitellopy import Tello

mp_hands = mp.solutions.hands

hands = mp_hands.Hands(max_num_hands=1)
# Load the trained model
with open("gesture_model.pkl", "rb") as f:
    model_data = pickle.load(f)
    clf = model_data['classifier']
    scaler = model_data['scaler']

prediction = None
stop_event = Event()
#stream

def call_repeatedly(interval, func, *args):
    def loop():
        while not stop_event.is_set():
            func(*args)  # Pass the scaler and classifier to the function
            stop_event.wait(interval)
    Thread(target=loop).start()
def hand_landmarks(scaler, clf):
    global prediction, frame_read
    frame = frame_read.frame
    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)  # Convert to RGB
    results = hands.process(frame_rgb)

    if results.multi_hand_landmarks:
        landmarks = np.array([[lmk.x, lmk.y, lmk.z] for lmk in results.multi_hand_landmarks[0].landmark]).flatten()
        landmarks = scaler.transform([landmarks])  # Normalize the landmarks
        prediction = clf.predict(landmarks)[0]  # Make a prediction
        print(f"Prediction: {prediction}")  # Debugging line to print prediction
    else:
        print("No hand landmarks detected.")

def control(tello):

    global frame_read, prediction
    if prediction:
        if prediction == 'like':  # otockalajk
            tello.rotate_clockwise(30)
        elif prediction == 'up':  # UP
            tello.move_up(25)
        elif prediction == 'palm':  # stop
            tello.forw_back_velocity = tello.up_down_velocity = (
                tello).left_right_velocity = tello.yaw_velocity = 0
        elif prediction == 'fist':  # forward
            tello.forw_back_velocity(30)
        elif prediction == 'ok':  # backwards
            tello.forw_back_velocity(-30)
        elif prediction == 'down':  # down
            (tello.move_down(25))
        elif prediction == 'peace':  # peace fotka
            cv2.imwrite("picture.png", frame_read.frame)









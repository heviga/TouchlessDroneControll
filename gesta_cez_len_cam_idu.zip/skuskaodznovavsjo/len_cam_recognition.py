import cv2
import mediapipe as mp
import numpy as np
import pickle
from threading import Thread, Event
mp_drawing = mp.solutions.drawing_utils

mp_hands = mp.solutions.hands
hands = mp_hands.Hands(max_num_hands=1)

# Load the trained model
with open("gesture_model.pkl", "rb") as f:
    clf = pickle.load(f)

def call_repeatedly(interval, func, stop_event):
    def loop():
        while not stop_event.is_set():
            func()
            stop_event.wait(interval)
    Thread(target=loop).start()

def hand_landmarks():
    global frame, prediction
    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    results = hands.process(frame_rgb)
    if results.multi_hand_landmarks:
        landmarks = results.multi_hand_landmarks[0].landmark
        landmarks = np.array([[lmk.x, lmk.y, lmk.z] for lmk in landmarks]).flatten()
        prediction = clf.predict([landmarks])[0]
        print(f"Prediction: {prediction}")  # Debugging line to print prediction

    else:
        print("No hand landmarks detected.")

cap = cv2.VideoCapture(0)
prediction = '0'
stop_event = Event()

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        continue
    frame = cv2.flip(frame, 1)

    key = cv2.waitKey(1)
    if key == ord("s"):
        # Start or restart the hand_landmarks calling
        stop_event.set()  # Stop any existing thread
        stop_event.clear()  # Reset the event
        call_repeatedly(1.5, hand_landmarks, stop_event)
    elif key == ord("q"):
        stop_event.set()  # Stop the hand_landmarks calling
        break

    cv2.putText(frame, prediction, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
    cv2.imshow("Frame", frame)

cap.release()
cv2.destroyAllWindows()

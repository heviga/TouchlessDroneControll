from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.metrics import classification_report
import pickle

# Load collected data
with open("gesture_data.pkl", "rb") as f:
    data, labels = pickle.load(f)

# TODO: Preprocess your data here to be hand-agnostic if not done during data collection

# Split the data into training and test sets
X_train, X_test, y_train, y_test = train_test_split(data, labels, test_size=0.2, random_state=42)

# Set the parameters for cross-validation
params = {'n_neighbors': [3, 5, 7, 9, 11]}

# Initialize the KNeighborsClassifier
knn = KNeighborsClassifier()

# Use GridSearchCV to find the best number of neighbors
clf = GridSearchCV(knn, params, cv=5)
clf.fit(X_train, y_train)

# Evaluate the classifier
y_pred = clf.predict(X_test)
print(classification_report(y_test, y_pred))

# Save the trained model
with open("gesture_model.pkl", "wb") as f:
    pickle.dump(clf, f)
